/********************************************************************************
** Form generated from reading UI file 'noobs.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOOBS_H
#define UI_NOOBS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_noobsClass
{
public:
    QWidget *centralWidget;
    QLineEdit *stunum;
    QPushButton *but1;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *classnum;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *name;
    QLabel *label_6;
    QLineEdit *stu_num;
    QLabel *label_7;
    QLabel *label_8;
    QLineEdit *class1;
    QLineEdit *class2;
    QLineEdit *grade1;
    QLineEdit *grade2;
    QLineEdit *class3;
    QLineEdit *class4;
    QLineEdit *class5;
    QLineEdit *class6;
    QLineEdit *class7;
    QLineEdit *class8;
    QLineEdit *grade3;
    QLineEdit *grade4;
    QLineEdit *grade7;
    QLineEdit *grade6;
    QLineEdit *grade5;
    QLineEdit *grade8;
    QPushButton *but2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *noobsClass)
    {
        if (noobsClass->objectName().isEmpty())
            noobsClass->setObjectName(QString::fromUtf8("noobsClass"));
        noobsClass->resize(1112, 568);
        centralWidget = new QWidget(noobsClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        stunum = new QLineEdit(centralWidget);
        stunum->setObjectName(QString::fromUtf8("stunum"));
        stunum->setGeometry(QRect(100, 0, 113, 21));
        but1 = new QPushButton(centralWidget);
        but1->setObjectName(QString::fromUtf8("but1"));
        but1->setGeometry(QRect(1020, 310, 93, 28));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 0, 161, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(0, 30, 151, 16));
        classnum = new QLineEdit(centralWidget);
        classnum->setObjectName(QString::fromUtf8("classnum"));
        classnum->setGeometry(QRect(150, 30, 113, 21));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(0, 80, 31, 16));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 80, 16, 16));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(0, 110, 31, 16));
        name = new QLineEdit(centralWidget);
        name->setObjectName(QString::fromUtf8("name"));
        name->setGeometry(QRect(40, 110, 113, 21));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(0, 150, 72, 15));
        stu_num = new QLineEdit(centralWidget);
        stu_num->setObjectName(QString::fromUtf8("stu_num"));
        stu_num->setGeometry(QRect(40, 150, 113, 21));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(0, 220, 72, 15));
        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(0, 260, 72, 15));
        class1 = new QLineEdit(centralWidget);
        class1->setObjectName(QString::fromUtf8("class1"));
        class1->setGeometry(QRect(50, 210, 113, 21));
        class2 = new QLineEdit(centralWidget);
        class2->setObjectName(QString::fromUtf8("class2"));
        class2->setGeometry(QRect(190, 210, 113, 21));
        grade1 = new QLineEdit(centralWidget);
        grade1->setObjectName(QString::fromUtf8("grade1"));
        grade1->setGeometry(QRect(50, 260, 113, 21));
        grade2 = new QLineEdit(centralWidget);
        grade2->setObjectName(QString::fromUtf8("grade2"));
        grade2->setGeometry(QRect(190, 260, 113, 21));
        class3 = new QLineEdit(centralWidget);
        class3->setObjectName(QString::fromUtf8("class3"));
        class3->setGeometry(QRect(330, 210, 113, 21));
        class4 = new QLineEdit(centralWidget);
        class4->setObjectName(QString::fromUtf8("class4"));
        class4->setGeometry(QRect(470, 210, 113, 21));
        class5 = new QLineEdit(centralWidget);
        class5->setObjectName(QString::fromUtf8("class5"));
        class5->setGeometry(QRect(610, 210, 113, 21));
        class6 = new QLineEdit(centralWidget);
        class6->setObjectName(QString::fromUtf8("class6"));
        class6->setGeometry(QRect(740, 210, 113, 21));
        class7 = new QLineEdit(centralWidget);
        class7->setObjectName(QString::fromUtf8("class7"));
        class7->setGeometry(QRect(870, 210, 113, 21));
        class8 = new QLineEdit(centralWidget);
        class8->setObjectName(QString::fromUtf8("class8"));
        class8->setGeometry(QRect(1000, 210, 113, 21));
        grade3 = new QLineEdit(centralWidget);
        grade3->setObjectName(QString::fromUtf8("grade3"));
        grade3->setGeometry(QRect(330, 260, 113, 21));
        grade4 = new QLineEdit(centralWidget);
        grade4->setObjectName(QString::fromUtf8("grade4"));
        grade4->setGeometry(QRect(470, 260, 113, 21));
        grade7 = new QLineEdit(centralWidget);
        grade7->setObjectName(QString::fromUtf8("grade7"));
        grade7->setGeometry(QRect(870, 260, 113, 21));
        grade6 = new QLineEdit(centralWidget);
        grade6->setObjectName(QString::fromUtf8("grade6"));
        grade6->setGeometry(QRect(740, 260, 113, 21));
        grade5 = new QLineEdit(centralWidget);
        grade5->setObjectName(QString::fromUtf8("grade5"));
        grade5->setGeometry(QRect(610, 260, 113, 21));
        grade8 = new QLineEdit(centralWidget);
        grade8->setObjectName(QString::fromUtf8("grade8"));
        grade8->setGeometry(QRect(1000, 260, 113, 21));
        but2 = new QPushButton(centralWidget);
        but2->setObjectName(QString::fromUtf8("but2"));
        but2->setGeometry(QRect(1020, 430, 93, 28));
        noobsClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(noobsClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1112, 26));
        noobsClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(noobsClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        noobsClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(noobsClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        noobsClass->setStatusBar(statusBar);

        retranslateUi(noobsClass);
        QObject::connect(but1, SIGNAL(clicked()), noobsClass, SLOT(on_but1_clicked()));
        QObject::connect(but2, SIGNAL(clicked()), noobsClass, SLOT(on_but2_clicked()));

        QMetaObject::connectSlotsByName(noobsClass);
    } // setupUi

    void retranslateUi(QMainWindow *noobsClass)
    {
        noobsClass->setWindowTitle(QApplication::translate("noobsClass", "noobs", nullptr));
        but1->setText(QApplication::translate("noobsClass", "\344\270\213\344\270\200\344\270\252", nullptr));
        label->setText(QApplication::translate("noobsClass", "\346\234\254\347\217\255\345\255\246\347\224\237\344\272\272\346\225\260\357\274\232", nullptr));
        label_2->setText(QApplication::translate("noobsClass", "\350\246\201\350\276\223\345\205\245\346\210\220\347\273\251\347\232\204\350\257\276\347\250\213\346\225\260\357\274\232", nullptr));
        label_3->setText(QApplication::translate("noobsClass", "\345\255\246\347\224\237", nullptr));
        label_4->setText(QApplication::translate("noobsClass", "1", nullptr));
        label_5->setText(QApplication::translate("noobsClass", "\345\247\223\345\220\215", nullptr));
        label_6->setText(QApplication::translate("noobsClass", "\345\255\246\345\217\267", nullptr));
        label_7->setText(QApplication::translate("noobsClass", "\350\257\276\347\250\213\345\220\215", nullptr));
        label_8->setText(QApplication::translate("noobsClass", "\346\210\220\347\273\251", nullptr));
        but2->setText(QApplication::translate("noobsClass", "\345\257\274\345\207\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class noobsClass: public Ui_noobsClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOOBS_H
