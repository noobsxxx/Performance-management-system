#include "noobs.h"
#include<stdio.h>
#include<stdlib.h>
using namespace std;

QString subject[10];        /*�������пγ�����*/
QString number[100];         /*����ȫ��ѧ��*/
QString name[100];           /*����ȫ������*/
float score[100][10];       /*����ȫ�����пγ̳ɼ�*/
float sum[100];               /*����ȫ���ܳɼ�*/
int n, m;
int i = 0;

noobs::noobs(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

void noobs::on_but1_clicked()
{
    int j = 0;
    QString str = ui.stunum->text();
    n = str.toInt();
    str = ui.classnum->text();
    m = str.toInt();
    name[i] = ui.name->text();
    number[i] = ui.stu_num->text();
    str = ui.class1->text();
    subject[j] = str;
    str = ui.grade1->text();
    score[i][j++] = str.toFloat();
    str = ui.class2->text();
    subject[j] = str;
    str = ui.grade2->text();
    score[i][j++] = str.toFloat();
    str = ui.class3->text();
    subject[j] = str;
    str = ui.grade3->text();
    score[i][j++] = str.toFloat();
    str = ui.class4->text();
    subject[j] = str;
    str = ui.grade4->text();
    score[i][j++] = str.toFloat();
    str = ui.class5->text();
    subject[j] = str;
    str = ui.grade5->text();
    score[i][j++] = str.toFloat();
    str = ui.class6->text();
    subject[j] = str;
    str = ui.grade6->text();
    score[i][j++] = str.toFloat(); 
    str = ui.class7->text();
    subject[j] = str;
    str = ui.grade7->text();
    score[i][j++] = str.toFloat();
    str = ui.class8->text();
    subject[j] = str;
    str = ui.grade8->text();
    score[i][j++] = str.toFloat();
    for (int p = 0; p < m; p++) {
        sum[i] += score[i][p];
    }
    int k = i + 2;
    str = QString::number(k);
    ui.label_4->setText(str);
    i++;
}

void noobs::on_but2_clicked()
{
    FILE* fp;
    int p, q;
    char a[100] = { 0 };
    char b[100] = { 0 };
    if ((fp = fopen("�ɼ���.txt", "w")) == NULL)
    {
        return;
    }
    fprintf(fp, "������������%d ����¼��γ�����%d \n", n, m);
    for (p = 0; p < m; p++)
    {   
        strcpy(a, subject[p].toUtf8().data());
        fprintf(fp, "%s  ", a);
    }
    for (int x = 0; x < n; x++)
    {
        /*x = number[i].toStdString();
        y = name[i].toStdString();*/
        strcpy(a, number[x].toUtf8().data());
        strcpy(b, name[x].toUtf8().data());
        fprintf(fp, "%s %s:", a, b);
            for (q = 0; q < m; q++)
            {
                fprintf(fp, "%-5.lf ", score[x][q]);
        }
    }
    fclose(fp);
}
