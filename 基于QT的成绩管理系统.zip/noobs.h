#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_noobs.h"

class noobs : public QMainWindow
{
    Q_OBJECT

public:
    noobs(QWidget *parent = Q_NULLPTR);

private:
    Ui::noobsClass ui;

    private slots:
    void on_but1_clicked();
    void on_but2_clicked();
};
